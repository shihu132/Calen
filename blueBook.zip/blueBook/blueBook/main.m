//
//  main

//  blueBook

//
//  Created by 石虎 on 16/5/4.
//  Copyright © 2016年 shih. All rights reserved.
//

#import <UIKit/UIKit.h>



#import "SHAppDelegate.h"

int main(int argc, char * argv[]) {
    
    
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SHAppDelegate class]));
        
    }
    
    
    
}
