//
//  SHCollegeCalendarController.h

//
//  Created by 石虎 on 16/7/12.
//  Copyright © 2016年 shih. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHBaseClassViewController.h"

@interface SHCollegeCalendarController : SHBaseClassViewController

@property(nonatomic,strong)NSArray *dayArray;

@end
