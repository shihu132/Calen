//
//  SHCalendarDayM.h
//
//  Created by 石虎 on 16/7/14.
//  Copyright © 2016年 shih. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHCalendarDayM : NSObject


@property (nonatomic,assign)int dayId;

@property(nonatomic,copy)NSString *zhengquelv;//正确率

@property(nonatomic,copy)NSString *star_time;//开始答题时间


@end
