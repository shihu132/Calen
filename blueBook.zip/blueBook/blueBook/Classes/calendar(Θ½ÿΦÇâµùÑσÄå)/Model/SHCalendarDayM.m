//
//  SHCalendarDayM.m
//  blueBook
//
//  Created by 石虎 on 16/7/14.
//  Copyright © 2016年 shih. All rights reserved.
//

#import "SHCalendarDayM.h"

@implementation SHCalendarDayM
+ (NSDictionary *)replacedKeyFromPropertyName{
    
    return @{
             @"dayId" : @"id"
             
             };
}

@end
