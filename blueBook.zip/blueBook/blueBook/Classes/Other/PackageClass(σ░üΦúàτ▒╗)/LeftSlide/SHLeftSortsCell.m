//
//  SHLeftSortsCell.m
//  blueBook
//
//  Created by 石虎 on 16/6/24.
//  Copyright © 2016年 shih. All rights reserved.
//

#import "SHLeftSortsCell.h"

@implementation SHLeftSortsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

  
}

@end
