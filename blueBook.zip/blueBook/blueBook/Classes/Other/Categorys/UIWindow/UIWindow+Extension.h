//
//  UIWindow+Extension.h
//  传智彩票
//
//  Created by apple on 15/26.
//  Copyright (c) 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (Extension)

- (void)chooseRootViewController;
@end
