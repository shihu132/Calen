//
//  SHTabBarButton.m

//
//  Created by 石虎 on 16/5/4.
//  Copyright © 2016年 shih. All rights reserved.
//

#import "SHTabBarButton.h"

@implementation SHTabBarButton

/**什么也不做就可以取消系统按钮的高亮状态*/
- (void)setHighlighted:(BOOL)highlighted
{
}

@end
