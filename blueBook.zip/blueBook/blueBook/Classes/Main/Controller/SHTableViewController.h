//
//  SHTableViewController.h

//
//  Created by 石虎 on 16/5/4.
//  Copyright © 2016年 shih. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHNavigationController.h"


@interface SHTableViewController : UITabBarController

@property(nonatomic,strong) SHNavigationController *nav;

@end
