//
//  SHLeftSortsCell.h

//
//  Created by 石虎 on 16/6/24.
//  Copyright © 2016年 shih. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHLeftSortsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lineLable;

@end
