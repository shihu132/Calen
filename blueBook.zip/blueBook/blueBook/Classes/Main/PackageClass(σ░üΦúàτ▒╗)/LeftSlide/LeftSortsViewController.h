//
//  LeftSortsViewController.h
//  LGDeckViewController
//
//  Created by 石虎  15/3/31.
//  Copyright (c) 2015年 Jamie-Ling. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftSortsViewController : UIViewController

@property (nonatomic,strong) UITableView *tableview;
//侧滑
@property (nonatomic,strong) LeftSlideViewController *LeftSlideVC;
@end
